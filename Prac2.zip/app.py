
from flask import Flask

app = Flask(__name__)

@app.route("/")
def home():
    return """
    <html>
    <head>
        <title>Azure App Service Practical</title>
        <style>
            body {
                font-family: Arial;
                text-align: center;
                background: #eaf3ff;
                padding: 80px;
            }
            .container {
                background: white;
                padding: 40px;
                border-radius: 15px;
                max-width: 600px;
                margin: auto;
                box-shadow: 0 4px 15px #aaa;
            }
            h1 { color: #0078D4; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Welcome to Azure App Service!</h1>
            <h2>My Cloud Computing Practical</h2>
            <p>Application successfully deployed.</p>
            <p>Platform: Microsoft Azure</p>
            <p>Service Model: PaaS</p>
            <p>Responsibility: Application and Data Security</p>
        </div>
    </body>
    </html>
    """

if __name__ == "__main__":
    app.run()
